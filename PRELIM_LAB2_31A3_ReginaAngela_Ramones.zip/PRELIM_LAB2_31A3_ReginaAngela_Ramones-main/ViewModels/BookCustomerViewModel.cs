using angelith.Models;

namespace angelith.ViewModels
{
    public class BookCustomerViewModel
    {
        public Book Book { get; set; }
        public Customer Customer { get; set; }
    }
}
